

# Prints the filename and size of each file within a given compound file.
# Add the -extract flag to extract files to the current working directory.
# In order to make the extracted version of the index work, you have to copy
# the segments file from the compound index into the directory where the
# extracted files are stored.

import sys
from PyLucene import IndexReader

if len(sys.argv) < 2:
    print 'Usage: python index_reader.py [-extract] cfsfile'
else:
    IndexReader.main(sys.argv[1:])
