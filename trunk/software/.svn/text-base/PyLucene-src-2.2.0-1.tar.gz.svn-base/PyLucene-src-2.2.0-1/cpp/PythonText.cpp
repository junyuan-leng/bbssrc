/* ====================================================================
 * Copyright (c) 2004-2005 Open Source Applications Foundation.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions: 
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software. 
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 * ====================================================================
 */

#include "PyLucene.h"
#include <java/text/CharacterIterator.h>

#include "org/osafoundation/text/PythonBreakIterator.h"
#include "org/osafoundation/util/PythonException.h"

/**
 * The native functions declared in org.osafoundation.text.PythonBreakIterator
 * 
 * @author Andi Vajda
 */

namespace org {
    namespace osafoundation {
        namespace text {

            void PythonBreakIterator::incRef(void)
            {
                PythonGIL gil;
                Py_INCREF(*(PyObject **) &pythonBreakIterator);
            }

            void PythonBreakIterator::decRef(void)
            {
                finalizeObject(pythonBreakIterator);
            }

            jboolean PythonBreakIterator::isBoundary(jint offset)
            {
                PythonGIL gil;
                PyObject *pyOffset = PyInt_FromLong(offset);
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "isBoundary", pyOffset, NULL);

                Py_DECREF(pyOffset);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                jboolean b = PyObject_IsTrue(result);
                Py_DECREF(result);

                return b;
            }

            jint PythonBreakIterator::first(void)
            {
                PythonGIL gil;
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "first", NULL);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::following(jint offset)
            {
                PythonGIL gil;
                PyObject *pyOffset = PyInt_FromLong(offset);
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "following", pyOffset, NULL);

                Py_DECREF(pyOffset);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::preceding(jint offset)
            {
                PythonGIL gil;
                PyObject *pyOffset = PyInt_FromLong(offset);
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "preceding", pyOffset, NULL);

                Py_DECREF(pyOffset);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::last(void)
            {
                PythonGIL gil;
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "last", NULL);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::current(void)
            {
                PythonGIL gil;
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "current", NULL);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::next(void)
            {
                PythonGIL gil;
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "nextBoundary", NULL);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            jint PythonBreakIterator::previous(void)
            {
                PythonGIL gil;
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "previous", NULL);

                if (!result)
                    throw new org::osafoundation::util::PythonException();

                long n = PyInt_AsLong(result);
                Py_DECREF(result);

                return (jint) n;
            }

            /* not implemented */
            java::text::CharacterIterator *PythonBreakIterator::getText(void)
            {
                return NULL;
            }

            void PythonBreakIterator::setText(jstring text)
            {
                PythonGIL gil;
                PyObject *pyText = j2p(text);
                PyObject *result = callPython(*(PyObject **) &pythonBreakIterator, "setText", pyText, NULL);

                Py_DECREF(pyText);

                if (!result)
                    throw new org::osafoundation::util::PythonException();
            }

            /* not implemented */
            void PythonBreakIterator::setText(java::text::CharacterIterator *iterator)
            {
            }
        }
    }
}
