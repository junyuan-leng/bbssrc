
# sample needs to be rewritten to use MultiPhraseQuery

#import os, sys, unittest
#
#sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
#
#import lia.advsearching.PhrasePrefixQueryTest
#unittest.main(lia.advsearching.PhrasePrefixQueryTest)
