# stopanalyzer package
